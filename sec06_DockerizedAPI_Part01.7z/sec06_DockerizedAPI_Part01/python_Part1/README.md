## Fun and useful projects with Python

You can find the corresponding tutorials on my channel: [https://www.youtube.com/c/PythonEngineer](https://www.youtube.com/c/PythonEngineer)
