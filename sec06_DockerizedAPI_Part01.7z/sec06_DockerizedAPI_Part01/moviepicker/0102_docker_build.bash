# -t: tag name for docker image name
docker build -t python-imdb_v02 .
