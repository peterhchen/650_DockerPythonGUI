docker build -t python-fastapi .
